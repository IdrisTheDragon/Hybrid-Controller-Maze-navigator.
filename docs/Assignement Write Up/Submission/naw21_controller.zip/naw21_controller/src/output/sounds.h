#ifndef sounds_H
#define sounds_H


void musicPlayer();



#endif /* Sounds_H*/