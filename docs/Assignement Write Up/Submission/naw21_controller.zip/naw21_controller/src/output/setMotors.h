#ifndef setMotors_H
#define setMotors_H


#include "../RobotState.h"

void setMotors(struct RobotState * robotState);

#endif /* !setMotors_H*/