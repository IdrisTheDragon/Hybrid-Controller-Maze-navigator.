#ifndef ObstacleDetection_H
#define ObstacleDetection_H

void basicObstacleAvoidence(int LSpeed, int RSpeed);

void detectObstactle(struct RobotState * robotState);

#endif /* ObstacleDetection_H*/