#ifndef RobotCalibrate_H
#define RobotCalibrate_H


void calibrateSpeed(struct RobotState * robotState);


#endif /* RobotCalibrate_H*/

