#ifndef Light_H
#define Light_H


#include "../RobotState.h"
void getLight(struct RobotState * robotState);


#endif /* !Light_H*/