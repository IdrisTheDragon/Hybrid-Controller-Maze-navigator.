#ifndef Encoders_H
#define Encoders_H


#include "../RobotState.h"
void getEncoders(struct RobotState * robotState);


#endif /* !Encoders_H*/